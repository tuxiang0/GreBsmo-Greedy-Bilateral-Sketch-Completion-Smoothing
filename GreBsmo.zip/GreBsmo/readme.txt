This is a MATLAB package for Greedy Bilateral Smoothing (GreBsmo) proposed in

Tianyi Zhou and Dacheng Tao, "Greedy Bilateral Sketch, Completion and Smoothing", AISTATS 2013.

Which is a greedy algorithm for GoDec proposed in

Tianyi Zhou and Dacheng Tao, "GoDec: Randomized Low-rank & Sparse Matrix Decomposition in Noisy Case", ICML 2011.

Please cite these two papers if you use this code. Thanks a lot!


Please run TestGreGoDec.m at first to test the code on video data. You can also try other videos given in the package.

GreGoDec.m: code for GreBsmo algorithm
GoDec_test.m: test GreBsmo on synthetic data (this is how the phase diagram be generated in the AISTATS paper)
GreBackground.m: apply GreBsmo to video data X (rows are frames, columns are pixels)
TetstGreGoDec.m: apply GreBsmo to four video sequences


Send your questions to tianyi.david.zhou@gmail.com.

All right reserved, Tianyi Zhou, 2013.