function [errorO,errorL,errorS,errorG,time]=GoDec_test(m,n,rank,card,Smag,Gfac,tau,tol,power,k)

% Synthetic data
mn=min([m,n]);
rank=round(rank*mn);
L=(randn(m,rank)./sqrt(mn))*randn(rank,n);
card=round(card*m*n);
supp=randperm(m*n);
supp=supp(1:card);
s=random('Binomial',1,0.5,card,1);
s(s==0)=-1;
s=Smag.*s;
S=zeros(m,n);
S(supp)=s;
G=(Gfac/sqrt(mn)).*randn(m,n);
X=L+S+G;
normL=norm(L(:));
normS=norm(S(:));
normG=norm(G(:));

% Initialize
errorL=[];
errorS=[];
errorG=[];

% GoDec algltithms
[Lg,Sg,errorO.Gre,time]=GreGoDec(X,rank,tau,tol,power,k);
tempL=Lg-L;
errorL=[errorL;norm(tempL(:))/normL];
tempS=Sg-S;
errorS=[errorS;norm(tempS(:))/normS];
tempG=X-Lg-Sg-G;
errorG=[errorG;norm(tempG(:))/normG];